import numpy as np
from cvxpy import *
from lib import grid
import time

def optimisation_program(bids, offers, lines, nodes, shift_factors, admittance):

    bids_schedule = variable(len(bids), 1, name='bid')
    offers_schedule = variable(len(offers), 1, name='offer')

    bids_more_than_zero = greater_equals(bids_schedule, 0.)
    offers_more_than_zero = greater_equals(offers_schedule, 0.)

    # this is how we can call the optimisation later
    bids_max = parameter(len(bids), 1, name='max_bid')
    bids_less_than_bid = less_equals(bids_schedule, bids_max)
    offers_less_than_offer = less_equals(offers_schedule, lookup(offers, 'quantity'))

    # this is how we aggregate bids and offers to nodes
    # node_injections_from_bids_offers
    # it is constructed from knowing which node a bid or offer is from

    injections = injections_from_schedule(bids, offers, nodes) * schedule(bids_schedule, offers_schedule)
    flows = shift_factors * injections

    flow_greater_than_min = greater_equals(flows, lookup(lines, 'min_flow'))
    flow_less_than_max = less_equals(flows, lookup(lines, 'max_flow'))

    # I believe this is only necessary if the slack node has not been removed
    sum_injections_zero = equals(matrix(np.ones(injections.shape[0])) * injections, 0.)

    objective = lookup(bids, 'price').T * bids_schedule - lookup(offers, 'price').T * offers_schedule

    p = program(maximize(objective),
                [bids_more_than_zero, offers_more_than_zero,
                 bids_less_than_bid, offers_less_than_offer,
                 flow_greater_than_min, flow_less_than_max,
                 sum_injections_zero],
                [bids_max])

    return (p, bids_schedule, offers_schedule)

def injections_from_schedule(bids, offers, nodes):
    injections_from_schedule = np.zeros((len(nodes), len(bids) + len(offers)))
    for node_idx, node in enumerate(nodes):
        for bid_idx, bid in enumerate(bids):
            if bid['node'] == node['name']:
                injections_from_schedule[node_idx, bid_idx] = -1.
        for offer_idx, offer in enumerate(offers):
            if offer['node'] == node['name']:
                injections_from_schedule[node_idx, len(bids) + offer_idx] = +1.
    return matrix(injections_from_schedule)

def schedule(bids, offers):
    return vstack((bids, offers))

def lookup(array, lookupee):
    return matrix([a[lookupee] for a in array]).T


if __name__ == '__main__':
    import unittest
    import numpy.testing as npt

    class Test4NodeModel(unittest.TestCase):
        def test_4_node_model(self):
            from test import four_node_network
            bids, offers, lines, nodes, shift_factors, admittance = four_node_network.create_dummy_network()
            p, bids_schedule, offers_schedule = optimisation_program(bids, offers, lines, nodes,
                    shift_factors, admittance)

            p(lookup(bids, 'quantity'))
            expected_answer = np.array([70., 42.5, 150.]).reshape(3,1)
            npt.assert_almost_equal(expected_answer, bids_schedule.value, decimal=1)

    class TestSimonModel(unittest.TestCase):
        def test_load_data(self):
            nodes, lines, shift_factors, admittance = grid.load_simon_network()
            from test import adelaide_brisbane_plus_some_randoms
            bids, offers = adelaide_brisbane_plus_some_randoms.create_test_bids_offers(nodes)

            self.assertEqual(nodes[-1]['name'], 'OLYMPICDAM')
            self.assertEqual(nodes[-4]['name'], 'ADELAIDE')
            npt.assert_almost_equal(lines[0]['min_flow'], -15467.)
            npt.assert_almost_equal(offers[0]['price'], 30.)

        def test_simple_optimisation(self):
            nodes, lines, shift_factors, admittance = grid.load_simon_network()
            from test import adelaide_brisbane_plus_some_randoms
            bids, offers = adelaide_brisbane_plus_some_randoms.create_test_bids_offers(nodes)
            program, bids_schedule, offers_schedule = optimisation_program(bids, offers,
                    lines, nodes, shift_factors, admittance)

            start = time.time()
            program(lookup(bids, 'quantity'))
            end = time.time()
            print '\nTime taken to solve 1 iteration of optimal power flow: %0.2fs' % (end - start)

            npt.assert_almost_equal(round(bids_schedule.value[0]), 150.)

    unittest.main()
