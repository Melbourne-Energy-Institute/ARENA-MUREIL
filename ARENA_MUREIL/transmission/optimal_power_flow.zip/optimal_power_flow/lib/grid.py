import numpy as np
from cvxpy import *

def load_simon_network(remove_slack_node=True):
    filenames = {'nodes': 'input_data/nodes.csv',
                 'lines': 'input_data/lines.csv',
                 'shift_factors': 'input_data/shift_factors.csv',
                 'admittance': 'input_data/admittance.csv'}

    nodes = []
    import csv
    with open(filenames['nodes'], 'rU') as n:
        reader = csv.reader(n)
        for row in reader:
            if reader.line_num == 1:
                continue
            else:
                nodes.append({'name': row[1]})

    lines = []
    with open(filenames['lines'], 'rU') as l:
        reader = csv.reader(l)
        for row in reader:
            if reader.line_num == 1:
                continue
            else:
                lines.append({'node from': row[1],
                              'node to': row[2],
                              'min_flow': float(row[3]),
                              'max_flow': float(row[4])})

    admittance = matrix(np.genfromtxt(filenames['admittance'], dtype=float,
                                      delimiter=',', skip_header=0))
    if remove_slack_node:
        nodes = nodes[1:]
        shift_factors = matrix(np.genfromtxt(filenames['shift_factors'], dtype=float,
                                      delimiter=',', skip_header=0))
        admittance = -1. * admittance[1:, :]
    else:
        shift_factors = matrix(np.zeros((len(lines), len(nodes))))
        shift_factors[:, 1:] = matrix(np.genfromtxt(filenames['shift_factors'], dtype=float,
                                      delimiter=',', skip_header=0))
        admittance = -1. * admittance

    return nodes, lines, shift_factors, admittance

