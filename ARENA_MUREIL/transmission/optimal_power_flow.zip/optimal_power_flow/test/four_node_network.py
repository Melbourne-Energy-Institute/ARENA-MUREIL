from cvxpy import matrix

def create_dummy_network():
    bids = []
    bids.append({'node': 'c', 'price': 200., 'quantity': 70.})
    bids.append({'node': 'c', 'price': 77., 'quantity': 60.})
    bids.append({'node': 'd', 'price': 500., 'quantity': 150.})

    offers = []
    offers.append({'node': 'a', 'price': 55., 'quantity': 100.})
    offers.append({'node': 'a', 'price': 75., 'quantity': 100.})
    offers.append({'node': 'b', 'price': 40., 'quantity': 50.})
    offers.append({'node': 'b', 'price': 70., 'quantity': 50.})
    offers.append({'node': 'd', 'price': 35., 'quantity': 10.})
    offers.append({'node': 'd', 'price': 80., 'quantity': 10.})

    lines = []
    lines.append({'min_flow': -65., 'max_flow': +65.})
    lines.append({'min_flow': -100., 'max_flow': +100.})
    lines.append({'min_flow': -50., 'max_flow': +50.})
    lines.append({'min_flow': -135., 'max_flow': +135.})

    nodes = []
    nodes.append({'name': 'a'})
    nodes.append({'name': 'b'})
    nodes.append({'name': 'c'})
    nodes.append({'name': 'd'})

    shift_factors = matrix([[0.5, 0.25, 0., 0.25],
                           [0.5, -0.25, 0., -0.25],
                           [0.5, 0.75, 0., 0.75],
                           [0., 0., 0., -1.]])

    admittance = matrix([[-1., -1., 0., 0.],
                         [0., 1., -1., -1.],
                         [1., 0., 1., 0.],
                         [0., 0., 0., 1.]])

    return bids, offers, lines, nodes, shift_factors, admittance

