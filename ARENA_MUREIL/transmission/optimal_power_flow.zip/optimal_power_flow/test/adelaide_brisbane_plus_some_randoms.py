
def create_test_bids_offers(nodes):
    offers = [{'node': 'ADELAIDE', 'price': 30., 'quantity': 130.}]
    bids = [{'node': 'BRISBANE', 'price': 500., 'quantity': 150.}]

    import random
    for node in nodes:
        if (node['name'] == 'BRISBANE'):
            pass
        else:
            bids.append({'node': node['name'], 'price': 120., 'quantity': float(random.randint(50,150))})

        if (node['name'] == 'ADELAIDE'):
            pass
        else:
            offers.append({'node': node['name'], 'price': 100., 'quantity': float(random.randint(200,300))})

    return bids, offers

